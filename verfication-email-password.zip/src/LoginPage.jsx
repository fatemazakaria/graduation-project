import React, { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Link, useNavigate } from "react-router-dom";

// ===== VALIDATION SCHEMA =====
const signInSchema = z.object({
  email: z
    .string()
    .min(1, { message: "البريد الإلكتروني مطلوب" })
    .email({ message: "بريد إلكتروني غير صالح" }),
  password: z
    .string()
    .min(8, { message: "كلمة المرور يجب أن تكون 8 أحرف على الأقل" })
    .regex(/.*[!@#$%^&*()_+{}|[\]\\:",'<>?,./].*/, {
      message: "يجب أن تحتوي كلمة المرور على حرف خاص واحد على الأقل",
    }),
  userType: z.enum(["student", "teacher"], {
    required_error: "الرجاء اختيار نوع المستخدم",
  }),
});

function LoginPage() {
  const navigate = useNavigate();
  const [isHovering, setIsHovering] = useState(false);
  const [isHoveringForgot, setIsHoveringForgot] = useState(false);
  const [isHoveringSignup, setIsHoveringSignup] = useState(false);
  const [userType, setUserType] = useState("student");

  // Responsive states
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);
  const [isTablet, setIsTablet] = useState(
    window.innerWidth > 768 && window.innerWidth <= 1024
  );
  const [isDesktop, setIsDesktop] = useState(window.innerWidth > 1024);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= 768);
      setIsTablet(window.innerWidth > 768 && window.innerWidth <= 1024);
      setIsDesktop(window.innerWidth > 1024);
    };

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
    setValue,
  } = useForm({
    resolver: zodResolver(signInSchema),
    defaultValues: {
      userType: "student",
    },
  });

  const onSubmit = async (data) => {
    console.log("بيانات الدخول:", data);
    await new Promise((resolve) => setTimeout(resolve, 1500));
    alert("تم تسجيل الدخول بنجاح!");
  };

  const handleForgotPassword = () => {
    navigate("/forget-password"); // ✅ التعديل هنا
  };

  // ============ STYLES ============
  // Container Styles
  const containerStyle = {
    minHeight: "100vh",
    backgroundImage:
      "url('https://images.pexels.com/photos/655837/pexels-photo-655837.jpeg?_gl=1*9jm1s8*_ga*MTU3NjgzMDczMC4xNzU4NjAzNjg2*_ga_8JE65Q40S6*czE3NjcwNDIyOTQkbzEwJGcxJHQxNzY3MDQyMzQ5JGo1JGwwJGgw')",
    backgroundRepeat: "no-repeat",
    backgroundSize: "cover",
    backgroundPosition: "center",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
    overflow: "hidden",
    fontFamily: "'Cairo', sans-serif",
    padding: isMobile ? "10px" : isTablet ? "20px" : "20px",
  };

  // Logo Styles
  const logoStyle = {
    position: "absolute",
    fontFamily: "Cairo",
    fontWeight: 700,
    lineHeight: "120%",
    textAlign: "center",
    color: "#FFFFFF",
    opacity: 1,
    zIndex: 10,
    ...(isMobile
      ? {
          top: "15px",
          right: "15px",
          fontSize: "clamp(24px, 8vw, 32px)",
        }
      : isTablet
      ? {
          top: "20px",
          right: "20px",
          fontSize: "clamp(32px, 5vw, 40px)",
        }
      : {
          top: "20px",
          right: "clamp(20px, 3vw, 40px)",
          fontSize: "clamp(40px, 3.5vw, 52px)",
        }),
  };

  // Glass Card
  const glassCardStyle = {
    borderRadius: isMobile ? "15px" : "20px",
    background: "rgba(28, 28, 28, 0.35)",
    backdropFilter: "blur(10px)",
    WebkitBackdropFilter: "blur(10px)",
    display: "flex",
    flexDirection: "column",
    alignItems: "flex-end",
    position: "relative",
    border: "1px solid rgba(255, 255, 255, 0.1)",
    width: "100%",
    maxWidth: isMobile ? "100%" : isTablet ? "600px" : "750px",
    padding: isMobile ? "20px 15px" : isTablet ? "30px 25px" : "35px 45px",
    margin: isMobile
      ? "60px auto 20px"
      : isTablet
      ? "70px auto 20px"
      : "40px auto",
  };

  // Header Styles
  const headerContainerStyle = {
    width: "100%",
    marginBottom: isMobile ? "20px" : isTablet ? "25px" : "30px",
    textAlign: "right",
  };

  const mainTitleStyle = {
    width: "100%",
    fontFamily: "Cairo",
    fontWeight: 700,
    lineHeight: "120%",
    textAlign: "right",
    color: "#F5FFF5",
    opacity: 1,
    fontSize: isMobile
      ? "clamp(28px, 6vw, 36px)"
      : isTablet
      ? "clamp(36px, 5vw, 42px)"
      : "clamp(38px, 3.5vw, 48px)",
    marginBottom: isMobile ? "5px" : isTablet ? "8px" : "10px",
  };

  const subtitleStyle = {
    width: "100%",
    fontFamily: "Cairo",
    fontWeight: 500,
    lineHeight: "140%",
    textAlign: "right",
    color: "#F5FFF5",
    opacity: 0.9,
    fontSize: isMobile
      ? "clamp(14px, 3.5vw, 16px)"
      : isTablet
      ? "clamp(16px, 2.5vw, 18px)"
      : "clamp(18px, 2vw, 22px)",
  };

  // Form Styles
  const formContainerStyle = {
    width: "100%",
    display: "flex",
    flexDirection: "column",
    gap: isMobile ? "12px" : isTablet ? "15px" : "18px",
  };

  const fieldContainerStyle = {
    display: "flex",
    flexDirection: "column",
    alignItems: "flex-end",
    width: "100%",
  };

  const fieldLabelStyle = {
    width: "100%",
    fontFamily: "Cairo",
    fontWeight: 700,
    lineHeight: "120%",
    textAlign: "right",
    color: "#F5FFF5",
    opacity: 1,
    fontSize: isMobile
      ? "13px"
      : isTablet
      ? "14px"
      : "clamp(14px, 1.5vw, 16px)",
    marginBottom: isMobile ? "5px" : isTablet ? "6px" : "8px",
  };

  const inputFieldStyle = {
    width: "100%",
    borderRadius: "8px",
    border: "1.5px solid #CCCCCC",
    fontFamily: "Cairo",
    color: "#333",
    backgroundColor: "#FFFFFF",
    textAlign: "right",
    outline: "none",
    transition: "all 0.3s ease",
    height: isMobile ? "42px" : isTablet ? "45px" : "clamp(45px, 6vh, 52px)",
    padding: isMobile ? "8px 12px" : isTablet ? "8px 16px" : "8px 20px",
    fontSize: isMobile
      ? "13px"
      : isTablet
      ? "14px"
      : "clamp(14px, 1.5vw, 16px)",
  };

  // Forgot Password Link
  const forgotPasswordLinkStyle = {
    color: isHoveringForgot ? "#66BB6A" : "#FFFBED",
    textDecoration: isHoveringForgot ? "underline" : "none",
    textAlign: "left",
    display: "block",
    marginTop: "5px",
    cursor: "pointer",
    fontFamily: "Cairo",
    fontWeight: 500,
    transition: "all 0.3s ease",
    fontSize: isMobile
      ? "11px"
      : isTablet
      ? "12px"
      : "clamp(12px, 1.2vw, 13px)",
    width: "100%",
  };

  // Radio Buttons
  const radioButtonsContainerStyle = {
    width: "100%",
    display: "flex",
    justifyContent: "flex-end",
    gap: isMobile ? "20px" : isTablet ? "30px" : "40px",
    marginTop: "5px",
    marginBottom: "5px",
  };

  const radioOptionStyle = {
    display: "flex",
    alignItems: "center",
    cursor: "pointer",
    color: "#FFFFFF",
    fontFamily: "Cairo",
    fontWeight: 700,
    gap: isMobile ? "5px" : isTablet ? "6px" : "8px",
    fontSize: isMobile
      ? "13px"
      : isTablet
      ? "14px"
      : "clamp(14px, 1.5vw, 16px)",
  };

  const radioCircleStyle = (selected) => ({
    display: "flex",
    width: isMobile ? "16px" : isTablet ? "18px" : "20px",
    height: isMobile ? "16px" : isTablet ? "18px" : "20px",
    borderRadius: "50%",
    alignItems: "center",
    justifyContent: "center",
    transition: "all 0.3s ease",
    border: `2px solid ${selected ? "#438846" : "rgba(255, 255, 255, 0.5)"}`,
  });

  const radioInnerCircleStyle = {
    borderRadius: "50%",
    backgroundColor: "#438846",
    width: isMobile ? "8px" : isTablet ? "10px" : "12px",
    height: isMobile ? "8px" : isTablet ? "10px" : "12px",
  };

  // Submit Button
  const submitButtonStyle = {
    width: "100%",
    borderRadius: "8px",
    backgroundColor: isHovering ? "#2E7D32" : "#438846",
    color: "#FFFFFF",
    fontFamily: "Cairo",
    fontWeight: 700,
    border: "none",
    cursor: "pointer",
    transition: "all 0.3s ease",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    transform: isHovering ? "translateY(-2px)" : "translateY(0)",
    boxShadow: isHovering
      ? "0 4px 20px rgba(67, 136, 70, 0.4)"
      : "0 2px 10px rgba(67, 136, 70, 0.2)",
    height: isMobile ? "40px" : isTablet ? "44px" : "clamp(44px, 6vh, 50px)",
    fontSize: isMobile
      ? "14px"
      : isTablet
      ? "15px"
      : "clamp(15px, 1.8vw, 18px)",
    marginTop: isMobile ? "10px" : isTablet ? "12px" : "15px",
  };

  // Signup Link
  const signupLinkContainerStyle = {
    width: "100%",
    textAlign: "center",
    marginTop: isMobile ? "10px" : isTablet ? "12px" : "15px",
    marginBottom: isMobile ? "5px" : isTablet ? "8px" : "10px",
  };

  const signupLinkWrapperStyle = {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    gap: "5px",
    flexDirection: "row",
    flexWrap: "wrap",
  };

  const signupLinkTextStyle = {
    fontFamily: "Cairo",
    color: "#F5FFF5",
    opacity: 0.9,
    fontSize: isMobile
      ? "13px"
      : isTablet
      ? "14px"
      : "clamp(14px, 1.5vw, 15px)",
  };

  const signupLinkStyle = {
    color: isHoveringSignup ? "#F5FFF5" : "#F5FFF5",
    textDecoration: "none",
    fontWeight: 700,
    cursor: "pointer",
    fontSize: isMobile
      ? "13px"
      : isTablet
      ? "14px"
      : "clamp(14px, 1.5vw, 15px)",
    transition: "all 0.3s ease",
    whiteSpace: "nowrap",
  };

  // Footer Text
  const footerTextStyle = {
    width: "100%",
    fontFamily: "Amiri Quran",
    fontWeight: 400,
    color: "rgba(245, 255, 245, 0.7)",

    textAlign: "center",
    lineHeight: "1.5",
    paddingTop: isMobile ? "8px" : isTablet ? "10px" : "12px",
    marginTop: isMobile ? "5px" : isTablet ? "8px" : "10px",
    fontSize: isMobile
      ? "clamp(14px, 3.5vw, 16px)"
      : isTablet
      ? "clamp(16px, 2.5vw, 18px)"
      : "clamp(18px, 2vw, 20px)",
  };

  const errorMessageStyle = {
    color: "#FF6B6B",
    marginTop: "4px",
    textAlign: "right",
    fontFamily: "Cairo",
    fontSize: isMobile ? "11px" : isTablet ? "12px" : "13px",
    width: "100%",
  };

  return (
    <div style={containerStyle}>
      {/* Logo Text */}
      <div style={logoStyle}>مِيرَاثاً</div>

      {/* Glass Card */}
      <div style={glassCardStyle}>
        {/* Header Container */}
        <div style={headerContainerStyle}>
          <h1 style={mainTitleStyle}>مرحباً بعودتك</h1>
          <p style={subtitleStyle}>
            ابدأ رحلتك مع العلم الذي يرفعك في الدنيا والآخرة.
          </p>
        </div>

        {/* Form Container */}
        <form onSubmit={handleSubmit(onSubmit)} style={formContainerStyle}>
          {/* Email Field */}
          <div style={fieldContainerStyle}>
            <label style={fieldLabelStyle}>البريد الإلكتروني</label>
            <input
              type="email"
              {...register("email")}
              style={{
                ...inputFieldStyle,
                borderColor: errors.email ? "#FF6B6B" : "#CCCCCC",
              }}
              placeholder="example@email.com"
            />
            {errors.email && (
              <div style={errorMessageStyle}>{errors.email.message}</div>
            )}
          </div>

          {/* Password Field */}
          <div style={fieldContainerStyle}>
            <label style={fieldLabelStyle}>كلمة المرور</label>
            <input
              type="password"
              {...register("password")}
              style={{
                ...inputFieldStyle,
                borderColor: errors.password ? "#FF6B6B" : "#CCCCCC",
              }}
              placeholder="أدخل كلمة المرور"
            />

            {/* Forgot Password Link */}
            <a
              style={forgotPasswordLinkStyle}
              onClick={handleForgotPassword}
              onMouseEnter={() => setIsHoveringForgot(true)}
              onMouseLeave={() => setIsHoveringForgot(false)}
            >
              نسيت كلمة المرور؟
            </a>

            {errors.password && (
              <div style={errorMessageStyle}>{errors.password.message}</div>
            )}
          </div>

          {/* Radio Buttons Container */}
          <div style={radioButtonsContainerStyle}>
            <label
              style={radioOptionStyle}
              onClick={() => {
                setUserType("student");
                setValue("userType", "student");
              }}
            >
              <div style={radioCircleStyle(userType === "student")}>
                {userType === "student" && (
                  <div style={radioInnerCircleStyle}></div>
                )}
              </div>
              طالب
            </label>

            <label
              style={radioOptionStyle}
              onClick={() => {
                setUserType("teacher");
                setValue("userType", "teacher");
              }}
            >
              <div style={radioCircleStyle(userType === "teacher")}>
                {userType === "teacher" && (
                  <div style={radioInnerCircleStyle}></div>
                )}
              </div>
              معلم
            </label>
          </div>

          {errors.userType && (
            <div style={{ ...errorMessageStyle, textAlign: "center" }}>
              {errors.userType.message}
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isSubmitting}
            style={submitButtonStyle}
            onMouseEnter={() => setIsHovering(true)}
            onMouseLeave={() => setIsHovering(false)}
          >
            {isSubmitting ? "جاري التسجيل..." : "تسجيل الدخول"}
          </button>
        </form>

        {/* Signup Link Container */}
        <div style={signupLinkContainerStyle}>
          <div style={signupLinkWrapperStyle}>
            <span style={signupLinkTextStyle}>ليس لديك حساب؟</span>
            <Link
              to="/signup"
              style={signupLinkStyle}
              onMouseEnter={() => setIsHoveringSignup(true)}
              onMouseLeave={() => setIsHoveringSignup(false)}
            >
              إنشاء حساب
            </Link>
          </div>
        </div>

        {/* النص القرآني */}
        <div style={footerTextStyle}>
          ﴿ ثُمَّ أَوْرَثْنَا الْكِتَابَ الَّذِينَ اصْطَفَيْنَا مِنْ عِبَادِنَا
          ﴾
        </div>
      </div>
    </div>
  );
}

export default LoginPage;
