// OTPPage.jsx
import React, { useState, useEffect } from "react";
import { useNavigate, useLocation, Link } from "react-router-dom";
import { createTheme } from "@mui/material/styles";
import {
  Container,
  Paper,
  Typography,
  TextField,
  Button,
  Box,
  Link as MuiLink,
  Alert,
  Stack,
} from "@mui/material";
import { styled } from "@mui/material/styles";

const StyledPaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(5),
  fontFamily: "'Cairo',sans-serif",
  borderRadius: "20px",
  background: "rgba(255, 255, 255, 0.95)",
  backdropFilter: "blur(10px)",
  boxShadow: "0 25px 50px rgba(0, 0, 0, 0.35)",
}));

const OTPInput = styled(TextField)(({ theme }) => ({
  "& .MuiOutlinedInput-root": {
    width: "90px",
    height: "30px",
    fontSize: "10px",
    textAlign: "center",
    borderRadius: "10px",
    backgroundColor: "#f5f5f5",
    "& input": {
      textAlign: "center",
      padding: 0,
    },
  },
}));

function OTPPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const [otp, setOtp] = useState(["", "", "", ""]);
  const email = location.state?.email || "ndkfi@gmail.com";
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [timer, setTimer] = useState(60);

  useEffect(() => {
    let interval;
    if (timer > 0) {
      interval = setInterval(() => {
        setTimer((prevTimer) => prevTimer - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [timer]);

  const handleOtpChange = (index, value) => {
    if (value.length > 1) return;
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);
    if (value !== "" && index < 3) {
      document.getElementById(`otp-${index + 1}`).focus();
    }
  };

  const handleKeyDown = (index, e) => {
    if (e.key === "Backspace" && otp[index] === "" && index >
     0) {
      document.getElementById(`otp-${index - 1}`).focus();
    }
  };

  const handleSubmit = async () => {
    const otpCode = otp.join("");
    if (otpCode.length < 4) {
      setError("يرجى إدخال الكود المكون من 4 أرقام");
      return;
    }

    setLoading(true);
    setError("");

    try {
      await new Promise((resolve) => setTimeout(resolve, 1500));
      alert("تم التحقق بنجاح! ✅");
      navigate("/");
    } catch (err) {
      setError("الكود غير صحيح، حاول مرة أخرى");
    } finally {
      setLoading(false);
    }
  };

  const handleResend = () => {
    setTimer(60);
    alert(`تم إعادة إرسال الكود إلى ${email}`);
  };

  return (
    <Container
      maxWidth="xl"
      sx={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        bgcolor: "#f5f5f5",
        py: 4,
      }}
    >
      <StyledPaper elevation={3}>
        <Typography
          variant="h5"
          fontWeight="bold"
          color="#000000"
          gutterBottom
          align="center"
          sx={{ mb: 3 }}
        >
          التأكد من البريد الإلكتروني
        </Typography>

        <Typography
          variant="body2"
          color="#000000"
          align="center"
          sx={{ mt: 1 }}
        >
          تم إرسال كود إلى
        </Typography>

        <Typography
          variant="h6"
          fontWeight="medium"
          align="center"
          sx={{ mb: 4 }}
        >
          {email}
        </Typography>

        {error && (
          <Alert severity="error" sx={{ mb: 3, borderRadius: 2 }}>
            {error}
          </Alert>
        )}

        <Stack
          direction="row"
          spacing={2}
          justifyContent="center"
          sx={{ mb: 4 }}
        >
          {[0, 1, 2, 3].map((index) => (
            <OTPInput
              key={index}
              id={`otp-${index}`}
              value={otp[index]}
              onChange={(e) => handleOtpChange(index, e.target.value)}
              onKeyDown={(e) => handleKeyDown(index, e)}
              variant="outlined"
              inputProps={{
                maxLength: 1,
                style: { textAlign: "center" },
              }}
            />
          ))}
        </Stack>

        <Button
          type="submit"
          variant="contained"
          fullWidth
          size="large"
          disabled={loading}
          disableRipple
          sx={{
            py: 2,
            fontSize: "1.1rem",
            borderRadius: 2,
            mt: 2,
            mb: 3,
            background: "#458843 !important",
          }}
        >
          {loading ? "جاري التحقق..." : "استمرار"}
        </Button>
        <Box sx={{ mb: 2, textAlign: "center" }}>
          <Typography variant="body2" color="textSecondary" display="inline">
            لم يصلك الكود؟{" "}
          </Typography>
          <MuiLink
            component="button"
            variant="body2"
            onClick={handleResend}
            disabled={timer > 0}
            sx={{
              fontWeight: "bold",
              cursor: timer > 0 ? "default" : "pointer",
              color: timer > 0 ? "gray" : "#255528",
            }}
          >
            اضغط هنا لإعادة الإرسال
          </MuiLink>
        </Box>

        {timer > 0 && (
          <Typography
            variant="caption"
            color="textSecondary"
            align="center"
            display="block"
          >
            يمكنك إعادة الإرسال بعد {timer} ثانية
          </Typography>
        )}

        <Box sx={{ textAlign: "center", mt: 3 }}>
          <span
            onClick={() => navigate("/login")}
            style={{
              color: "#000000",
              cursor: "pointer",
              textDecoration: "none",
              fontSize: "0.875rem",
            }}
            onMouseEnter={(e) => (e.target.style.textDecoration = "underline")}
            onMouseLeave={(e) => (e.target.style.textDecoration = "none")}
          >
            ← العودة إلى تسجيل الدخول
          </span>
        </Box>
      </StyledPaper>
    </Container>
  );
}

export default OTPPage;
